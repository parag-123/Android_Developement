package com.parag.guessgame;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnContextClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {

    private EditText txtGuess;
    private Button btnGuess;
    private TextView lblOutput;
    private int theNumber;
    private int totalTries;
    private int triesLeft = 7;

    public void checkGuess() {

        //Get the number which user entered

        String theirnumber = txtGuess.getText().toString();
        String message = "";

        try {

            int guess = Integer.parseInt(theirnumber);
            totalTries ++;
            triesLeft --;
            if (guess > theNumber & triesLeft > 0 ) { // too high
                message = guess + " Was too high, guess again. Tries left: "+ triesLeft;
                lblOutput.setText(message);
                        }
            else if (guess< theNumber & triesLeft > 0){ // too low
                message = guess + " Was too low, guess again. Tries left: "+ triesLeft;
                lblOutput.setText(message);
            }
            else if (triesLeft <= 0){ // correct
                message = " You Lost. No tries left";
                lblOutput.setText(message);
                newGame();
                triesLeft = 7;
            }
            else { // correct
                message = guess + " Was correct. You Win!!, Play Again. You tried: " + totalTries + " times";
                lblOutput.setText(message);
                newGame();
            }
        }
        catch(Exception ex){
            message = "Please enter a whole number";
            lblOutput.setText(message);
        }
        finally {// highlight the txtGuess text field
            txtGuess.requestFocus();
            txtGuess.selectAll();


    }}


        private void newGame(){
        theNumber = (int)(Math.random()*100 +1);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtGuess = (EditText)findViewById(R.id.txtGuess);
        btnGuess = (Button) findViewById(R.id.btnGuess);
        lblOutput = (TextView) findViewById(R.id.lblOutput);

        newGame();
        //Setup event listener to button press
        btnGuess.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGuess();
            }

        });
        //Setup event listener for input field
        txtGuess.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
               checkGuess();
                return true;
            }
        });



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
