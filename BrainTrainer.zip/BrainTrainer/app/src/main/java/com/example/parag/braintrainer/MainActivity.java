package com.example.parag.braintrainer;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.IntegerRes;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {
    //EditText welcome;
        EditText question;
        EditText timer;
        EditText score;
         EditText result;
        Button start;
        Button option1;
        Button option2;
        Button option3;
        Button option4;
        Button playAgain;
    CountDownTimer myCountDownTimerObject;
    String pressed;
    //boolean isRunning = false;
    int a = 0;
    int b = 0;

    ArrayList<Integer> answers = new ArrayList<>();
    int locationOfCorrectAnswer;


    public void questions (View view) {

        question.setVisibility(View.VISIBLE);
        timer.setVisibility(View.VISIBLE);
        score.setVisibility(View.VISIBLE);
        option1.setVisibility(View.VISIBLE);
        option2.setVisibility(View.VISIBLE);
        option3.setVisibility(View.VISIBLE);
        option4.setVisibility(View.VISIBLE);
        start.setVisibility(View.INVISIBLE);
        result.setVisibility(View.VISIBLE);
        //welcome.setVisibility(View.INVISIBLE);


        setUp();



        myCountDownTimerObject = new CountDownTimer(30000,1000){

            public void onTick(long millisecondsUntilDone){
                // countdown is counting down (everysecond)

                //Log.i ("Seconds left", String.valueOf(millisecondsUntilDone/1000));

                // timer.setText(String.valueOf(millisecondsUntilDone/1000));


                 //isRunning = true;
                timer.setText(String.format("%s S", String.valueOf(millisecondsUntilDone/1000)));
            }

            public void onFinish (){
                 //isRunning = false;
                result.setText("Your Score is: " + score.getText() );
                 a = 0;
                 b = 0;
                playAgain.setVisibility(View.VISIBLE);
                myCountDownTimerObject.cancel();
                timer.setText("0S");
                score.setText("0/0");
                option1.setEnabled(false);
                option2.setEnabled(false);
                option3.setEnabled(false);
                option4.setEnabled(false);



            }
        }.start();


    }

    public void correctAnswer (View view) {
        pressed = view.getTag().toString();

        if (pressed.equals(Integer.toString(locationOfCorrectAnswer))) {
            a++;


            result.setText("Correct!");

        } else {


            result.setText("Wrong!");

        }
        b++;
        score.setText(a + "/" + b);

        setUp();


    }







    public void setUp (){
        Random rand = new Random();
        int num1 = rand.nextInt(21);
        int num2 = rand.nextInt(21);
        //int other = rand.nextInt(15);
        //int other1 = rand.nextInt(15);
        //int other2 = rand.nextInt(15);

        //int sum = num1 + num2;


        question.setText(String.format("%d + %d", num1,num2));



        locationOfCorrectAnswer = rand.nextInt(4);


        answers.clear();

        int incorrectAnswer;


        for (int i =0; i<4; i++) {

            if (i == locationOfCorrectAnswer) {

                answers.add(num1+num2);

            } else {

                incorrectAnswer = rand.nextInt(41);

                if ( incorrectAnswer == num1+num2){
                    incorrectAnswer = rand.nextInt(41);
                }
                answers.add (incorrectAnswer);
            }

        }

        option1.setText(Integer.toString(answers.get(0)));
        option2.setText(Integer.toString(answers.get(1)));
        option3.setText(Integer.toString(answers.get(2)));
        option4.setText(Integer.toString(answers.get(3)));





    }



    public void playAgain (View view) {

        myCountDownTimerObject.start();
        playAgain.setVisibility(View.INVISIBLE);
        result.setText("");
        score.setText("0/0");
        option1.setEnabled(true);
        option2.setEnabled(true);
        option3.setEnabled(true);
        option4.setEnabled(true);

        setUp();

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        question = (EditText)findViewById(R.id.editText3);
        timer = (EditText)findViewById(R.id.editText);
        score = (EditText)findViewById(R.id.editText2);
        option1 = (Button)findViewById(R.id.button0);
        option2 = (Button)findViewById(R.id.button1);
        option3 = (Button)findViewById(R.id.button2);
        option4 = (Button)findViewById(R.id.button3);
        start = (Button)findViewById(R.id.button);
        result = (EditText)findViewById(R.id.editText4);
        playAgain = (Button)findViewById(R.id.button11);
        //welcome = (EditText)findViewById(R.id.textView2);






    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
