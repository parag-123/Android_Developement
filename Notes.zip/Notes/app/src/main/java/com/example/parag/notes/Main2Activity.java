package com.example.parag.notes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import static com.example.parag.notes.MainActivity.notes;

public class Main2Activity extends AppCompatActivity implements TextWatcher {

    EditText addNote ;
    int noteID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        setTitle("Save Notes");
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        addNote = (EditText) findViewById(R.id.editText);

    Intent i = getIntent();
        noteID = i.getIntExtra("noteID", -1);

        // if value is -1 then there is no data in notes array

        if (noteID != -1){
        addNote.setText(MainActivity.notes.get(noteID));

        }
// Save edited note abck to same note
        addNote.addTextChangedListener(this);





    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //notes.add(addNote.getText().toString());

                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
// notes will be updated
        notes.set(noteID,String.valueOf(charSequence));
        // update arrayadaptor
        MainActivity.adapter.notifyDataSetChanged();

        SharedPreferences sp = this.getSharedPreferences("com.example.parag.notes", Context.MODE_PRIVATE);

        if (MainActivity.set == null){

            MainActivity.set = new HashSet<String>();

        }else {

            MainActivity.set.clear();
        }



        MainActivity.set.addAll(notes);

        sp.edit().remove("notes").apply();
        sp.edit().putStringSet("notes",MainActivity.set).apply();

        sp.edit().commit();
        MainActivity.adapter.notifyDataSetChanged();

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
