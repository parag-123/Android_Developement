package com.example.parag.guessthecelebrity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    Button option1;
    Button option2;
    Button option3;
    Button option4;
    ImageView image;
    HashMap<String, String> abc;
    ArrayList<String> nameOfFlowers = new ArrayList<>();
    ArrayList<String> imageOfFlowers = new ArrayList<>();

    int chosenCeleb = 0;
    int locationOfCorrectAnswer = 0;
    String[] answers = new String[4];

    public void correctAnswer(View view) {

        // Show a toast if answer is correct
        // Show wrong and celebrity name if answer is wrong
        // show another question with image and options changed


    }

    public class ImageDownloader extends AsyncTask<String, Void, Bitmap> {


        @Override
        protected Bitmap doInBackground(String... urls) {

            try {

                URL url = new URL(urls[0]);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                connection.connect();

                InputStream inputStream = connection.getInputStream();

                Bitmap myBitmap = BitmapFactory.decodeStream(inputStream);

                return myBitmap;


            } catch (MalformedURLException e) {

                e.printStackTrace();

            } catch (IOException e) {

                e.printStackTrace();

            }

            return null;
        }
    }

    public class TextDownloader extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... urls) {
            String result = "";// store html content of webpage
            URL url;
            HttpURLConnection urlConnection = null; // browser

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();// open browser and open url
                InputStream in = urlConnection.getInputStream();// stream to hold input of data

                InputStreamReader reader = new InputStreamReader(in); //Read contents of URL.

                // one character at a time
                int data = reader.read();

                // continosly reading char from input stream reader and appending it to reslt.

                while (data != -1) {

                    char current = (char) data;

                    result += current;
                    data = reader.read(); // move data to new character

                }

                return result; // return result to original task in oncreate method
            } catch (Exception e) {

                e.printStackTrace();
                return "Failed to catch the exception";
            }


        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        option1 = (Button) findViewById(R.id.button4);
        option2 = (Button) findViewById(R.id.button3);
        option3 = (Button) findViewById(R.id.button2);
        option4 = (Button) findViewById(R.id.button);
        image = (ImageView) findViewById(R.id.imageView);

        TextDownloader textTask = new TextDownloader();
        String result = null;
        try {
            result = textTask.execute("http://www.namesofflowers.net/names-of-all-flowers.html").get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        Pattern p = Pattern.compile("img src=\"(.*?)\"");

        Matcher m = p.matcher(result);

        while (m.find()) {

            imageOfFlowers.add(m.group(1));

        }

        Pattern q = Pattern.compile("alt=\"(.*?)\" width");
        Matcher n = q.matcher(result);


        while (n.find()) {

            nameOfFlowers.add(n.group(1));

        }

        //createNewQuestion();
        Log.i ("nameOfFlowers", nameOfFlowers.toString());
        Log.i ("imageOfFlowers", imageOfFlowers.toString());

        createNewQuestion();
    }


    public void createNewQuestion() {

        Random random = new Random();
        chosenCeleb = random.nextInt(imageOfFlowers.size());

        ImageDownloader imageTask = new ImageDownloader();

        Bitmap celebImage;

        try {

            celebImage = imageTask.execute(imageOfFlowers.get(chosenCeleb)).get();

            image.setImageBitmap(celebImage);

            locationOfCorrectAnswer = random.nextInt(4);

            int incorrectAnswerLocation;

            for (int i=0; i<4; i++) {

                if (i == locationOfCorrectAnswer) {

                    answers[i] = nameOfFlowers.get(chosenCeleb);

                } else {

                    incorrectAnswerLocation = random.nextInt(imageOfFlowers.size());

                    while (incorrectAnswerLocation == chosenCeleb) {

                        incorrectAnswerLocation = random.nextInt(imageOfFlowers.size());

                    }

                    answers[i] = nameOfFlowers.get(incorrectAnswerLocation);


                }


            }

            option1.setText(answers[0]);
            option2.setText(answers[1]);
            option3.setText(answers[2]);
            option4.setText(answers[3]);


        } catch (Exception e) {
            e.printStackTrace();
        }




    }

}



